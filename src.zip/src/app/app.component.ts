import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(){}




  ngOnInit(){
  }





}




//NOTA1: Se hacen las Importaciones de Proyecto por si se llegan a usar
//pero en este caso solo se está usando refresh-ses

//NOTA2: Si se necesitan códigos constantes que se ejecuten
//independiente de que ruta se esté se incluye aquí como
// refresh para refrescará al sesión.

//NOTA3: refresh-ses refresca la sesión cada cierto tiempo
//se hace desde aquí porque es un Código de Ejecución constante.