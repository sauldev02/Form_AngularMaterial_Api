import { TestBed } from '@angular/core/testing';

import { ConnectBasicService } from './connect-basic.service';

describe('ConnectBasicService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConnectBasicService = TestBed.get(ConnectBasicService);
    expect(service).toBeTruthy();
  });
});
