import { Injectable } from '@angular/core';



import { 
 	HttpClient,HttpErrorResponse, HttpParams,	
	HttpHeaders
} from '@angular/common/http';

 import { Observable, throwError } from 'rxjs';
 import { map, catchError } from 'rxjs/operators';






@Injectable({
  providedIn: 'root'
})
export class ConnectBasicService{

   data;

   constructor(private http:HttpClient) { }



   httpPost(url,objeto){

    return this.http.post(url,objeto)
      .pipe(
        map((res)=>{
          this.data=res;
          return this.data;
        }),
        catchError(this.handleError)
        );

   }





	private handleError(error: HttpErrorResponse) {
	  console.log(error);
	  return throwError('Error de Conexión!');
	}










}

