
export class Send{
	
	constructor(
		public formProducto,
	 	public conexion,
	 	public url
	){}



	sendData(fun,fun_error){


    this.conexion.httpPost(`${this.url}`,{

		  'IdProducto': this.formProducto.get('IdProducto').value,
		  'IdTipo': this.formProducto.get('IdTipo').value,
		  'IdTipoServicio': this.formProducto.get('IdTipoServicio').value,
		  'Codigo': this.formProducto.get('Codigo').value,
		  'Nombre': this.formProducto.get('Nombre').value,
		  'Activo': this.convertActivo(this.formProducto.get('Activo').value),
		  'IdStatus': this.formProducto.get('IdStatus').value,
		  'FechaStatus': this.formProducto.get('FechaStatus').value,
		  'IdMarca': this.formProducto.get('IdMarca').value,
		  'IdUnidadMedida': this.formProducto.get('IdUnidadMedida').value,
		  'Presentacion': this.formProducto.get('Presentacion').value,
		  'Costo': this.formProducto.get('Costo').value,
		  'PrecioSubDist': this.formProducto.get('PrecioSubDist').value,
		  'PrecioMayoreo': this.formProducto.get('PrecioMayoreo').value,
		  'PrecioPublico': this.formProducto.get('PrecioPublico').value,
		  'StockMinimo': this.formProducto.get('StockMinimo').value,
		  'StockMaximo': this.formProducto.get('StockMaximo').value,
		  'Ubicacion': this.formProducto.get('Ubicacion').value,
		  'FechaAlta': this.formProducto.get('FechaAlta').value,
		  'IdMotivoBaja': this.formProducto.get('IdMotivoBaja').value,
		  'FechaBaja': this.formProducto.get('FechaBaja').value,
		  'DescripcionMotivoBaja': this.formProducto.get('DescripcionMotivoBaja').value,
		  'Tags': this.formProducto.get('Tags').value,
		  'Foto': this.formProducto.get('Foto').value,
		  'IdUsuario': this.formProducto.get('IdUsuario').value
	    
	    }).subscribe(
        (res)=>{

        	fun(res)

        },
        (err)=>{
          fun_error(err)
        }
    )

	}






	convertActivo(Activo){
		return Activo==1?true:false
	}




}