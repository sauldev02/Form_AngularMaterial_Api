import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SendingDataComponent } from './sending-data.component';



const routes: Routes = [
	{path:'',component: SendingDataComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SendingDataRoutingModule { }
