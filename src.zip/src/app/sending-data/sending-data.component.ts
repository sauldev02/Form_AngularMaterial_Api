import { Component, OnInit } from '@angular/core';

import {FormControl,FormGroup,FormBuilder} from "@angular/forms";

//Services
import { ConnectBasicService } from '../plugins/connect/connect-basic.service';

//Table
import {Producto} from '../table/producto';

//Cls
import {Send} from './Cls/send'


import {environment} from '../../environments/environment';






@Component({
  selector: 'app-sending-data',
  templateUrl: './sending-data.component.html',
  styleUrls: ['./sending-data.component.css']
})
export class SendingDataComponent implements OnInit {

  url=environment.DIRECTION;

  checked = false;



	producto_set=new Producto()


  formProducto: FormGroup

  constructor(
  	private form_builder: FormBuilder,
  	private conexion:ConnectBasicService
  	){}



  //Instancia de send...
  instanceSend(){
  	return new Send(this.formProducto,this.conexion,this.url)
  }



  //Enviar Datos...
  sendData(){

  	this.instanceSend().sendData(
  		(res)=>{
  			console.log(res)
  		},
  		(err)=>{
  			console.log(err)
  		}
  	)
  }





  //Construir...
  builderProducto(){
    this.formProducto = this.form_builder.group( this.producto_set )  	
  }









  ngOnInit(){
    this.builderProducto()
  }





}
