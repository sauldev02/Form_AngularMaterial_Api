import {FormControl,Validators} from "@angular/forms";

export class Producto{

  IdProducto=new FormControl(0,[Validators.required])
  IdTipo=new FormControl(0,[Validators.required])
  IdTipoServicio=new FormControl(0,[Validators.required])
  Codigo=new FormControl('',[Validators.required])
  Nombre=new FormControl('',[Validators.required])
  Activo=new FormControl(1,[Validators.required])  //Boolean
  IdStatus=new FormControl(0,[Validators.required])
  FechaStatus=new FormControl('2020-08-29T15:15:15.643Z',[Validators.required])
  IdMarca=new FormControl(0,[Validators.required])
  IdUnidadMedida=new FormControl(0,[Validators.required])
  Presentacion=new FormControl('',[Validators.required])
  Costo=new FormControl(0,[Validators.required])
  PrecioSubDist=new FormControl(0,[Validators.required])
  PrecioMayoreo=new FormControl(0,[Validators.required])
  PrecioPublico=new FormControl(0,[Validators.required])
  StockMinimo=new FormControl(0,[Validators.required])
  StockMaximo=new FormControl(0,[Validators.required])
  Ubicacion=new FormControl('',[Validators.required])
  FechaAlta=new FormControl('2020-08-29T15:15:15.643Z',[Validators.required])

  IdMotivoBaja=new FormControl(0,[Validators.required])
  FechaBaja=new FormControl('2020-08-29T15:15:15.643Z',[Validators.required])
  DescripcionMotivoBaja=new FormControl('',[Validators.required])
  Tags=new FormControl('',[Validators.required])
  Foto=new FormControl('',[Validators.required])
  IdUsuario=new FormControl(0,[Validators.required])


	constructor(){}

}



