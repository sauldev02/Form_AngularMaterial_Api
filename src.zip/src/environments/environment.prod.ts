export const environment = {
  production: true,

	DIRECTION:'https://sanitiza.azurewebsites.net/api/Productos/Inserta'
  //DIRECTION:'http://localhost/'



};
